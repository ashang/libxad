#ifndef _version_h
#define _version_h

#define	VERSION			"2.4"
#define VERSION_DATE	"26 Oct 1999"

#endif  /* _version_h */

