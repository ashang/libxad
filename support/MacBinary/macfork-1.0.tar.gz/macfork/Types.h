/*
    File:       Types.h

    Function:	

    Author:     Andrew Willmott

    Copyright:  (c) 1999, Andrew Willmott
*/

#ifndef __Types__
#define __Types__

typedef char            Char;
typedef unsigned char   Byte;
typedef int             Int;
typedef void            Void;

#endif
