
int MIMEH_set_verbosity( int level );
int MIMEH_set_outputdir( char *dir );


