

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "XAM_strtok.h"


/*------------------------------------------------------------------------
 Procedure:     XAM_strncasecmp ID:1
 Purpose:       Portable version of strncasecmp(), this may be removed in later
                versions as the strncase* type functions are more widely
                 implemented
 Input:
 Output:
 Errors:
------------------------------------------------------------------------*/
int XAM_strncasecmp( char *s1, char *s2, int n )
{
	char *ds1 = s1, *ds2 = s2;
	char c1, c2;
	int result = 0;

	while(n > 0)
	{
		c1 = tolower(*ds1);
		c2 = tolower(*ds2);

		if (c1 == c2)
		{
			n--;
			ds1++;
			ds2++;
		}
		else
		{
			result = c2 - c1;
			n = 0;
		}

	}

	return result;

}





/*------------------------------------------------------------------------
 Procedure:     XAM_strtok ID:1
 Purpose:       A thread safe version of strtok()
 Input:
 Output:
 Errors:
------------------------------------------------------------------------*/
char *XAM_strtok( struct _txstrtok *st, char *line, char *delimeters )
{
	char *stop;
	char *p;
	char *result = NULL;

	if ( line )
	{
		st->start = line;
	}

	result = st->start;

	if (st->start)
	{
		stop = strpbrk( st->start, delimeters ); /* locate our next delimeter */

		if (stop)
		{
			*stop = '\0';
			if (*(stop+1) == '\0') st->start = NULL;
			else
			{
				stop++;
				while (*stop)
				{
					p = strpbrk(stop, delimeters);
					if (!p) break;
					else if (p == stop) stop++;
					else break;
				}
				if ((*stop)&&(p)) st->start = stop; else st->start = NULL;
			}
		}
		else st->start = NULL;
	}


	return result;
}

