/* zstrncpy.c - Copy a specified number of bytes from string to string */

#include <stddef.h>

/*
 * Copy characters from `src' to `dst', writing not more than `len'
 * characters to the destination string, including the terminating
 * NUL (\0) byte.
 */
char *zstrncpy (char *dst, const char *src, size_t len)
{
	char *dp = dst;
	const char *sp = src;

	if (len == 0)
		return dst;

		//PLD - changed --len -> len--

	while ((len != 0) && (*sp != '\0'))
	{
		*dp++ = *sp++;
		len--;
	}

	*dp = '\0';

	return dst;
}
