/*------------------------------------------------------
*
 * MIME.C
*
 * This file is the core component of the ripMIME
* and other packages
*
 * Sun Jan 28 16:16:12 EST 2001 worker <worker@xamime>
* 	Prerelease stage 1 completed.
* Sat Jan 13 21:05:51 EST 2001 worker <worker@xamime>
* 	Going into PreRelease stage 1.
*
 * Sat Nov 25 16:25:06 SAST 2000 worker <worker@xamime>
* 	Add some more comments, as more people are reading this
* 	c code ;)
*
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <ctype.h>
#include <sys/stat.h>
#include <unistd.h>
#include <time.h>
#include <errno.h>

#include "XAM_strtok.h"
#include "strlower.h"
#include "ffget.h"
#include "mime.h"
#include "tnef/tnef_api.h"
#include "zstrncpy.h"
#include "MIME_headers.h"

#define _SL 1

#define _ENC_UNKNOWN 0
#define _ENC_BASE64 1
#define _ENC_PLAINTEXT 2
#define _ENC_QUOTED 3
#define _ENC_EMBEDDED 4
#define _ENC_NOFILE -1
#define _MIME_CHARS_PER_LINE 32
#define _MIME_MAX_CHARS_PER_LINE 76
#define _RECURSION_LEVEL_MAX 20

#define _BOUNDARY_CRASH 2

/* single-character decode */
#define UUDEC(c)  (((c) - ' ') & 077)

/* Debug Constants */

/* Debug precodes */
#define MIME_DPEDANTIC ((_MIME_debug >= _MIME_DEBUG_PEDANTIC))
#define MIME_DNORMAL   ((_MIME_debug >= _MIME_DEBUG_NORMAL  ))


/*----Structures-----*/
struct _MIME_info {
	int lastlinewasboundary;	/* Last line we read in had the boundary in it */
	int lastlinewasfrom;		 /* last line we read in had the From: line proceeded by a blank */
	int lastlinewasblank;		/* (part of lastlinewasfrom) */
	int lastencoding;			 /* the encoding specifier last read in */
	int boundarylen;			  /* Length of the boundary */
	char *inputok;				 /* Indicator of file reading sanity */
	char boundary[_MIME_STRLEN_MAX]; 		 /* The boundary */
	char filename[_MIME_STRLEN_MAX];		  /* Filename of current attachment */
	char uudec_name[_MIME_STRLEN_MAX];	// UUDecode name. This is a post-decode information field.

};


/* our base 64 decoder table */
unsigned char b64[256];

char OK[]="OKAY";

// HexConversion table, rather than doing a atoi (with base 16)
//	16/11/2001	suggestion to use the static operation by Mark Leisher <mleisher@crl.nmsu.edu>
static int hexconv[256];

/* How many attachments have we produced */
int filecount = 0;

/* If the attachment has no name, then we will need it to have one (else how are you going store it on your system ? */
char blankfileprefix[_MIME_STRLEN_MAX]="textfile";

/* Verbosity - talk as we walk through the MIMEpack to the shell */
int _verbosity = 0;

/* Debug - Do we talk in detail as we decode... */
int _MIME_debug = 0;

/* Our logging options */
int syslogging = 0;
int stderrlogging = 1;

/* filename options */
int _MIME_no_uudecode = 0;
int _unique_names = 0;
int _no_paranoid = 0;
int _rename_method = _MIME_RENAME_METHOD_INFIX;

/* The name of the file which will contain all the non-attachment
* lines from the MIMEpack
*/
char headersname[_MIME_STRLEN_MAX]="_headers_";

char MIME_tmpdir[_MIME_STRLEN_MAX];

/* The variable that indicates (if not zero) that we are to dump our
* non-attachment lines to the file "headersname"
*/
int _dump_headers = 0;


/* Attachment count - how many attachment with FILENAMES */
int _attachment_count = 0;

/* Current line read number */
int _current_line = 0;

/* if we dont want nameless-files, this is non-zero */
int _no_nameless = 0;

/* Are we going to handle mailbox format */
int _mailbox_format = 0;

/* File pointer for the headers output */
FILE *headers;

struct _tbsnode {
	char *boundary;
	struct _tbsnode *next;
};

struct _tbsnode *boundarystack = NULL;
char boundarystacksafe[_MIME_STRLEN_MAX];

/*----------------------------------------------------------
* MIME_BS_push()
*
 * Push a boundary onto the stack */
int MIME_BS_push( char *boundary )
{

	struct _tbsnode *node = malloc(sizeof(struct _tbsnode));


	if (node)
	{
		node->next = boundarystack;
		boundarystack = node;
		boundarystack->boundary = strdup(boundary);
	}
	else
	    {
		if (syslogging > 0) syslog(_SL,"MIME_BS_push(): Cannot allocate memory for PUSH(), %s",strerror(errno));
	}

	return 0;
}


/*----------------------------------------------------------
* MIME_BS_pop()
*
 * pop's the top boundar off */
char *MIME_BS_pop( void )
{

	struct _tbsnode *node = boundarystack;
	if (boundarystack)
	{
		boundarystack = boundarystack->next;
		zstrncpy(boundarystacksafe,node->boundary,
			sizeof(boundarystacksafe));
		free(node);
	}

	return boundarystacksafe;
}

/*----------------------------------------------------------
* MIME_BS_top()
*
 * returns the top item in the stack, without popping off */
char *MIME_BS_top( void )
{

	if (boundarystack)
	{
		return boundarystack->boundary;
	}
	else return NULL;
}

/*----------------------------------------------------------
* MIME_BS_cmp()
*
 */
int MIME_BS_cmp( char *boundary, int len )
{

	char *top, *spot;
	char *testspace = malloc((len+1)*sizeof(char));
	int spin=1;
	struct _tbsnode *node=boundarystack;
	struct _tbsnode *nodetmp=NULL, *nodedel=NULL;

	if (!boundary) return 0;

	memcpy(testspace,boundary,len);
	*(testspace +len) = '\0';

	while((node)&&(spin))
	{
		top = node->boundary;
		spot = strstr(testspace,top);
		if (spot) spin = 0;
		else node = node->next;
	}

	// If we have a hit on the matching, then, according
	// to nested MIME rules, we must "remove" any previous
	// boundaries
	//
	if (spin == 0)
	{
		if (node != boundarystack)
		{
			nodetmp = boundarystack;
			while ((nodetmp)&&(nodetmp != node))
			{
				nodedel = nodetmp;
				nodetmp = nodetmp->next;
				free(nodedel);
			}
			boundarystack = node;
		}
		return 1;
	}

	else return 0;
}







/*------------------------------------------------------------------------
Procedure:     MIME_set_debug ID:1
Purpose:       Sets the debug level for reporting in MIME
Input:         int level : What level of debugging to use, currently there
are only two levels, 0 = none, > 0 = debug info
Output:
Errors:
------------------------------------------------------------------------*/
int MIME_set_debug( int level )
{
	_MIME_debug = level;

	TNEF_set_debug(level);

	return _MIME_debug;
}


/*------------------------------------------------------------------------
Procedure:     MIME_set_no_uudecode ID:1
Purpose:       Sets the uudecode option
Input:
Output:
Errors:
------------------------------------------------------------------------*/
int MIME_set_no_uudecode( int level )
{
	_MIME_no_uudecode = level;

	return 1;
}


/*------------------------------------------------------------------------
Procedure:     MIME_set_tmpdir ID:1
Purpose:       Sets the internal Temporary directory name.
Input:
Output:
Errors:
------------------------------------------------------------------------*/
int MIME_set_tmpdir( char *setto )
{

	strncpy(MIME_tmpdir,setto,1023);

	return 0;
}





/*-------------------------------------------------------
* MIME_set_blankfileprefix
*
* Sets the prefix for blank files
*
 * the blank file prefix is used when (typ) we have text
* attachments, ie, when there is both a HTML and a
* plain-text version of the message in the same email.
*
 */
int MIME_set_blankfileprefix( char *prefix )
{

	/* copy over the prefix name, ensure that we
	* dont break buffers here */
	zstrncpy(blankfileprefix,prefix,sizeof(blankfileprefix));

	return 0;
}


/*------------------------------------------------------------------------
Procedure:     MIME_get_blankfileprefix ID:1
Purpose:
Input:
Output:
Errors:
------------------------------------------------------------------------*/
char *MIME_get_blankfileprefix( void )
{
	return blankfileprefix;
}






/*-------------------------------------------------------
* MIME_set_verbosity
*
* By default, MIME reports nothing as its working
* Setting the verbosity level > 0 means that it'll
* report things like the name of the files it's
* writing/extracting.
*
 */
int MIME_set_verbosity( int level )
{

	_verbosity = level;

	TNEF_set_verbosity( level );

	return 0;
}




/*-------------------------------------------------------
* MIME_set_dumpheaders
*
 * By default MIME wont dump the headers to a text file
* but at times this is useful esp for checking
* for new styles of viruses like the KAK.worm
*
 * Anything > 0 will make the headers be saved
*
 */
int MIME_set_dumpheaders( int level )
{

	_dump_headers = level;

	return 0;
}


/*------------------------------------------------------
* MIME_set_headersname
*
* by default, the headers would be dropped to a file
* called '_headers_'.  Using this call we can make
* it pretty much anything we like
*/
int MIME_set_headersname( char *fname )
{

	zstrncpy(headersname, fname, sizeof(headersname));

	return 0;
}




/*------------------------------------------------------------------------
Procedure:     MIME_get_headersname ID:1
Purpose:       Returns a pointer to the current headersname string.
Input:
Output:
Errors:
------------------------------------------------------------------------*/
char *MIME_get_headersname( void )
{
	return headersname;
}



/*-------------------------------------------------------
* MIME_set_syslogging
*
 * By default, syslogging is off, setting the "level" to a value above zero(0)
* will make MIME log to the system
*/
int MIME_set_syslogging( int level )
{

	syslogging = level;
	TNEF_set_syslogging(level);

	return 0;
}


/*-------------------------------------------------------
* MIME_set_stderrlogging
*
 * By default logging is done via stderr, set this to zero (0) to turn off
*/
int MIME_set_stderrlogging(int level)
{

	stderrlogging = level;
	TNEF_set_stderrlogging(level);

	return 0;
}



/*------------------------------------------------------------------------
Procedure:     MIME_set_no_nameless ID:1
Purpose:
Input:
Output:
Errors:
------------------------------------------------------------------------*/
int MIME_set_no_nameless( int level )
{

	_no_nameless = level;

	return 0;
}

/*------------------------------------------------------------------------
Procedure:     MIME_set_uniquenames ID:1
Purpose:
Input:
Output:
Errors:
------------------------------------------------------------------------*/
int MIME_set_uniquenames( int level )
{
	_unique_names = level;

	return 0;
}




/*------------------------------------------------------------------------
Procedure:     MIME_set_noparanoid ID:1
Purpose:       If set, will prevent MIME from clobbering what it considers
to be non-safe characters in the file name.
Input:
Output:
Errors:
------------------------------------------------------------------------*/
int MIME_set_noparanoid( int level )
{
	_no_paranoid = level;
	return 0;
}




/*------------------------------------------------------------------------
Procedure:     MIME_set_mailboxformat ID:1
Purpose:       If sets the value for the _mailboxformat variable
in MIME, this indicates to functions later on
that they should be aware of possible mailbox
format specifiers.
Input:
Output:
Errors:
------------------------------------------------------------------------*/
int MIME_set_mailboxformat( int level )
{
	_mailbox_format = level;
	MIMEH_set_mailbox( level );
	return 0;
}


/*------------------------------------------------------------------------
Procedure:     MIME_set_renamemethod ID:1
Purpose:
Input:
Output:
Errors:
------------------------------------------------------------------------*/
int MIME_set_renamemethod( int method )
{
	if (( method >= _MIME_RENAME_METHOD_PREFIX ) && ( method <= _MIME_RENAME_METHOD_POSTFIX ))
	{
		_rename_method = method;
	}
	else
	    {
		//		#FIXME - make me report correct values to stderr or syslog
		return -1;
	}

	return 0;
}





/*------------------------------------------------------------------------
Procedure:     MIME_get_attachment_count ID:1
Purpose:
Input:
Output:
Errors:
------------------------------------------------------------------------*/
int MIME_get_attachment_count( void )
{
	return _attachment_count;
}




/*------------------------------------------------------------------------
Procedure:     MIME_test_uniquename ID:1
Purpose:
Input:
Output:
Errors:
------------------------------------------------------------------------*/
int MIME_test_uniquename( char *path, char *fname, int method )
{

	struct stat buf;

	char newname[_MIME_STRLEN_MAX +1];
	char scratch[_MIME_STRLEN_MAX +1];
	char *frontname, *extention;

	int cleared = 0;
	int count = 1;

	if (!scratch)
	{
		return -1;
	}

//DEBUG fprintf(stdout,"----------------------------\n");
//DEBUG fprintf(stdout,"mime.c: %d: input = %s\n",__LINE__,fname);

	frontname = extention = NULL;  // shuts the compiler up

	if (method == _MIME_RENAME_METHOD_INFIX)
	{
//DEBUG zstrncpy(scratch,fname,sizeof(scratch));
		snprintf(scratch,_MIME_STRLEN_MAX,"%s",fname);
		frontname = scratch;
		extention = strrchr(scratch,'.');
//DEBUG fprintf(stdout,"mime.c: %d: Scratch: %s - %s-%s\n",__LINE__,scratch,frontname,extention);

		if (extention)
		{
			*extention = '\0';
			extention++;
		}
		else
		{
			method = _MIME_RENAME_METHOD_POSTFIX;
		}
	}

	snprintf(newname,_MIME_STRLEN_MAX,"%s/%s",path,fname);

	while (!cleared)
	{
		if ((stat(newname, &buf) == -1))
		{
			cleared++;
		}
		else
		    {
			if (method == _MIME_RENAME_METHOD_PREFIX)
			{
				snprintf(newname,_MIME_STRLEN_MAX,"%s/%d_%s",path,count,fname);
			}
			else
				if (method == _MIME_RENAME_METHOD_INFIX)
				{
					snprintf(newname,_MIME_STRLEN_MAX,"%s/%s_%d.%s",path,frontname,count,extention);
				}
				else
					if (method == _MIME_RENAME_METHOD_POSTFIX)
					{
						snprintf(newname,_MIME_STRLEN_MAX,"%s/%s_%d",path,fname,count);
					}
			count++;
		}
	}

	if (count > 1)
	{
		frontname = strrchr(newname,'/');
		if (frontname) frontname++;
		else frontname = newname;

		zstrncpy(fname, frontname, _MIME_STRLEN_MAX);
	}

	return 0;
}




/*------------------------------------------------------------------------
 Procedure:     MIME_is_file_mime ID:1
 Purpose:       Determines if the file handed to it is a MIME type email file.

 Input:         file name to analyze
 Output:        Returns 0 for NO, 1 for YES, -1 for "Things di
 Errors:
------------------------------------------------------------------------*/
int MIME_is_file_mime( char *fname )
{
	char conditions[10][10] = { "From: ", "Subject: ", "Date: ", "Content-", "content-", "from: ", "subject: ", "date: " };
	int result = 0;
	int hitcount = 0;
	char *line;
	FILE *f;


	f = fopen(fname,"r");
	if (!f)
	{
		syslog(1,"MIME_is_file_mime: Error, cannot open file '%s' for reading (%s)",fname,strerror(errno));
		return 0;
	}

	line = malloc(sizeof(char) *1025);
	if (!line)
	{
		syslog(1,"MIME_is_file_mime: Error, cannot allocate memory for read buffer");
		return 0;
	}

	while ((hitcount < 2)&&(fgets(line,1024,f)))
	{
		for (result = 0; result < 8; result++)
		{
//DEBUG			fprintf(stdout,"Testing for : %s\n",conditions[result]);
			if (strstr(line,conditions[result])) hitcount++;
		}
	}

	fclose(f);

	if (hitcount >= 2) result = 1; else result = 0;

	if (line) free(line);

	return result;
}















/*-------------------------------------------------------
* MIME_base64_init
*
 * Prepare the base64 decoding array
*
 */
int MIME_base64_init( void )
{

	int i;

	/* preset every encodment to 0x80 */
	for (i = 0; i < 255; i++) b64[i] = 0x80;

	/* put in the capital letters */
	for (i = 'A'; i <= 'Z'; i++) b64[i] = 0 + (i - 'A');

	/* put in the lowere case letters */
	for (i = 'a'; i <= 'z'; i++) b64[i] = 26 + (i - 'a');

	/* the digits */
	for (i = '0'; i <= '9'; i++) b64[i] = 52 + (i - '0');

	/* and our special chars */
	b64['+'] = 62;
	b64['/'] = 63;
	b64['='] = 0;

	return 0;
}





/*-------------------------------------------------------------------*
 * MIME_clean_MIME_filename -
* 	Cleans up the file name, ie, strips it of unrequired
*	 inverted comma's etc.
*/
int MIME_clean_MIME_filename( char *fname )
{
	int fnl = strlen(fname); /* FileNameLength */
	char *fnp, *iso, fname_copy[1024];
	char tmp[1024];
	char *p = strrchr(fname,'/');
	struct _txstrtok xst;

	/* scan out any directory separators */
	if (p)
	{
		p++;
		zstrncpy(tmp,p,sizeof(tmp));
		zstrncpy(fname,tmp,_MIME_STRLEN_MAX);
	}
	else if ( (p = strrchr(fname,'\\')))
	{
		p++;
		zstrncpy(tmp,p,sizeof(tmp));
		zstrncpy(fname,tmp,_MIME_STRLEN_MAX);
	}



	if ((fnl > 2)&&(!strchr(fname,' ')))
	{  /* if there's no spaces in our MIME_filename */

		if (strstr(fname,"=?"))
		{ /* we may have an ISO filename */
			fnp = fname;
			iso = XAM_strtok(&xst,fname,"?");
			/*iso = strtok(fname,"?");  iso encoding prefix */
			if (iso) iso = XAM_strtok(&xst, NULL,"?"); /* The leading = */
			if (iso) iso = XAM_strtok(&xst, NULL,"?"); /* unknown singe char */
			if (iso) iso = XAM_strtok(&xst, NULL,"?"); /* filename! */
			if (iso) {
				MIME_decode_text_line(iso);
				zstrncpy(fname_copy,iso,sizeof(fname_copy));
				zstrncpy(fname,fname_copy,_MIME_STRLEN_MAX);
			}
		}
		/* if the MIME_filename starts and ends with "'s */
		if ((fname[0] == '\"') && (fname[fnl-1] == '\"'))
		{
			/* reduce the file namelength by two*/
			fnl=-2;

			/* shuffle the MIME_filename chars down */
			memmove(fname,fname+1,fnl);

			/* terminate the string */
			fname[fnl] = '\0';
		} /* if */
	} /* if */

	return 0;
}


/*-------------------------------------------------------------------*
 * quick_clean_filename -
* 	Cleans up filename by replacing non alfanum chars with '_'
*/
void quick_clean_filename( char *fname )
{
	char tmp[1024];
	char *p = strrchr(fname,'/');

	/* scan out any directory separators */
	if (p)
	{
		p++;
		zstrncpy(tmp,p,sizeof(tmp));
		zstrncpy(fname,tmp,_MIME_STRLEN_MAX);
	}
	else if ( (p = strrchr(fname,'\\')))
	{
		p++;
		zstrncpy(tmp,p,sizeof(tmp));
		zstrncpy(fname,tmp,_MIME_STRLEN_MAX);
	}


	while (*fname)
	{
		if (_no_paranoid == 0)
		{
			if( !isalnum(*fname) && (*fname != '.') ) *fname='_';
		}
		else
		    {
			if( (*fname < ' ')||(*fname > '~') ) *fname='_';
		}
		fname++;
	}
}




/*-------------------------------------------------------
* MIME_getchar_start
*
 * This routine is actually a copy of MIME_getchar()
* except that it'll return ONLY a valid MIME-encoded
* char, rather than also a \n
*
 */

int MIME_getchar_start( FFGET_FILE *f )
{

	int c;

	/* loop for eternity, as we're "returning out" */
	while (1)
	{

		/* get a single char from file */
		c = FFGET_fgetc(f);

		/* if that char is an EOF, or the char is something beyond
		* ASCII 32 (space) then return */
		if ((c == EOF) || (c > ' '))
		{
			return c;
		}

	} /* while */

	/* Although we shouldn't ever actually get here, we best put it in anyhow */
	return EOF;
}


/*------------------------------------------------------------------------
Procedure:     MIME_is_uuencode_header ID:1
Purpose:       Tries to determine if the line handed to it is a UUencode header.
Input:
Output:        0 = No
1 = Yes
Errors:
------------------------------------------------------------------------*/
int MIME_is_uuencode_header( char *line )
{
	struct _txstrtok tx;
	char buf[1024];
	char *bp,*fp;
	int result = 0;

	// If we're not supposed to be decoding UUencoded files, then return 0
	if (_MIME_no_uudecode) return 0;

	snprintf(buf,1023,"%s",line);

	bp = buf;
	if ((bp)&&(strncasecmp(bp,"begin",5)==0))
	{
		fp = NULL;
		bp = XAM_strtok(&tx, buf, " \n\r\t"); // Get the begin
		if (MIME_DNORMAL) fprintf(stdout,"MIME_is_uuencode_header: BEGIN = %s\n",bp);

		if (bp) fp = XAM_strtok(&tx, NULL, " \n\r\t"); // Get the file-permissions
		if (MIME_DNORMAL) fprintf(stdout,"MIME_is_uuencode_header: Permissions/Name = %s\n",fp);

		if (fp && bp) result = 1;
	}

	return result;
}





/*------------------------------------------------------------------------
 Procedure:     MIME_is_file_uuenc ID:1
 Purpose:       Tries to determine if a given file is UUEncoded, or at
                least contains a UUENCODED file to it.
                This should only be run -after- we've checked with
                is_file_mime() because if the file is MIME, then it'll be able
                to detect UUencoding within the normal decoding routines.
 Input:         filename to test
 Output:        0 = not uuencoded
                1 = _probably_ uuencoded.
 Errors:
------------------------------------------------------------------------*/
int MIME_is_file_uuenc( char *fname )
{
	int result = 0;
	int linecount = 0;
	int limit=20;
	char *line;
	FILE *f;

	f = fopen(fname,"r");
	if (!f)
	{
		syslog(1,"MIME_is_file_mime: Error, cannot open file '%s' for reading (%s)",fname,strerror(errno));
		return -1;
	}

	line = malloc(sizeof(char) *1025);
	if (!line)
	{
		syslog(1,"MIME_is_file_mime: Error, cannot allocate memory for read buffer");
		return -1;
	}

	while ((linecount < limit)&&(fgets(line,1024,f)))
	{
		if (MIME_DNORMAL) fprintf(stdout,"MIME_is_file_uuenc: Testing line '%s'\n",line);
		if (MIME_is_uuencode_header( line ))
		{
			result = 1;
			break;
		}
		linecount++;
	}

	fclose(f);

	if (line) free(line);

	return result;
}


/*------------------------------------------------------------------------
Procedure:     outdec ID:1
Purpose:       Outputs a group of 3 bytes from a 4 byte input
Input:
Output:
Errors:
------------------------------------------------------------------------*/
int MIME_outdec(char *p, FILE *f, int n)
{
	char c[3];

	c[0] = UUDEC(*p) << 2 | UUDEC(p[1]) >> 4;
	c[1] = UUDEC(p[1]) << 4 | UUDEC(p[2]) >> 2;
	c[2] = UUDEC(p[2]) << 6 | UUDEC(p[3]);

	if (n > 3) n = 3;
	fwrite(c, 1, n, f);

	/* - 1.2.9 - Removed this if-tree and replaced with the single fwrite()
	call.  Hope that this improves speed a little bit

	if (n >= 1) {
	fputc(c1, f);
	}
	if (n >= 2) {
	fputc(c2, f);
	}
	if (n >= 3) {
	fputc(c3, f);
	}
	*/

	return 0;
}



/*------------------------------------------------------------------------
Procedure:     MIME_decode_uu ID:1
Purpose:       Decodes a UUencoded stream
Input:
Output:
Errors:
------------------------------------------------------------------------*/
int MIME_decode_uu( char *unpackdir, struct _header_info *hinfo, int keep )
{
	int filename_found = 0;
	char buf[1024];
	char *bp = buf, *fn, *fp;
	int n, i, expected;
	char fullpath[1024]="";
	struct _txstrtok tx;
	FFGET_FILE finf;
	FILE *outf;
	FILE *inf;

	/* generate the filename, and open it up... */
	snprintf(fullpath,sizeof(fullpath),"%s/%s",unpackdir,hinfo->filename);
	inf = fopen(fullpath,"r");

	if (!inf)
	{
		if (MIME_DNORMAL) fprintf(stdout,"MIME_decode_uu: Cannot open file '%s' (%s)",fullpath, strerror(errno));
		if (syslogging > 0) syslog(_SL,"MIME_decode_uu: Cannot open file '%s' (%s)",fullpath,strerror(errno));
		if (stderrlogging > 0) fprintf(stderr,"MIME_decode_uu: Cannot open file '%s' (%s)",fullpath,strerror(errno));
		return -1;
	}


	if (MIME_DNORMAL) fprintf(stdout,"MIME_decode_uu: Beginning.(%s)\n",fullpath);

	FFGET_setstream(&finf, inf);

	while (!FFGET_feof(&finf))
	{
		filename_found = 0;

		// First lets locate the BEGIN line of this UUDECODE file

		while (FFGET_fgets(buf, sizeof(buf), &finf))
		{
			if (MIME_DNORMAL) fprintf(stdout,"MIME_decode_uu: Reading: %s\n",buf);
			if (strncasecmp(buf,"begin",5)==0)
			{
				// Okay, so the line contains begin at the start, now, lets get the decode details
				fp = fn = NULL;

				bp = XAM_strtok(&tx, buf, " \n\r\t"); // Get the begin
				if (MIME_DNORMAL) fprintf(stdout,"MIME_decode_uu: BEGIN = '%s'\n",bp);
				if (bp) fp = XAM_strtok(&tx, NULL, " \n\r\t"); // Get the file-permissions
				if (MIME_DNORMAL) fprintf(stdout,"MIME_decode_uu: Permissions/Name = '%s'\n",fp);
				if (fp) fn = XAM_strtok(&tx, NULL, " \n\r\t"); // Get the file-name
				if (MIME_DNORMAL) fprintf(stdout,"MIME_decode_uu: Name = '%s'\n",fn);

				if (!fn)
				{
					bp = fp;
				} else bp = fn;

				if (!bp)
				{
					fclose(inf);
					fprintf(stderr,"MIME_decode_uu: WARNING - unable to obtain filename from UUencoded text file header");
					return -1;
				}

				filename_found = 1;
				break;
			}
		}


		if ((filename_found)&&(bp))
		{
			// Clean up the file name
			snprintf(hinfo->uudec_name, 128, bp); // FIXME - replace 128 with real value.

			MIME_clean_MIME_filename( bp );
			quick_clean_filename( bp );

			// Create the new output full path

			snprintf(fullpath, sizeof(fullpath), "%s/%s",unpackdir,bp);
			outf = fopen(fullpath, "wb");

			if (!outf)
			{
				if (syslogging > 0) syslog(_SL,"MIME_decode_uu: Cannot open file '%s' (%s)",fullpath,strerror(errno));
				if (stderrlogging > 0) fprintf(stderr,"MIME_decode_uu: Cannot open file '%s' (%s)",fullpath,strerror(errno));
				return -1;
			}


			// Okay, now we have the UUDECODE data to decode...

			while (outf)
			{
				/* for each input line */
				if (FFGET_fgets(buf, sizeof(buf), &finf) == NULL)
				{
					fprintf(stderr,"MIME_decode_uu: Short file");
					return -1;
				}

				// If we've reached the end of the UUencoding

				if (strncasecmp(buf,"end",3)==0)
				{
					if (MIME_DNORMAL) fprintf(stdout,"End of UUencoding detected\n");
					break;
				}

				if ( !strpbrk(buf,"\r\n") )
				{
					fprintf(stderr,"MIME_decode_uu: WARNING - Excessive length line\n");
				}

				// The first char of the line indicates how many bytes are to be expected

				n = UUDEC(*buf);


				// If the line is a -blank- then break out.

				if ((n <= 0) || (*buf == '\n')) break;

				// Calculate expected # of chars and pad if necessary

				expected = ((n+2)/3)<<2;
				for (i = strlen(buf)-1; i <= expected; i++) buf[i] = ' ';
				bp = &buf[1];

				// Decode input buffer to output file.

				while (n > 0)
				{
					MIME_outdec(bp, outf, n);
					bp += 4;
					n -= 3;
				} // while (n > 0)

			} // While (1)

			if (outf) fclose(outf);
			if (_verbosity) fprintf(stdout,"Decoded %s\n",fullpath);

			// Increment the Attachment Counter

			_attachment_count++;

		} // If valid filename was found for UUdecode

		if (MIME_DNORMAL) fprintf(stdout,"MIME_uudec: Segment completed\n");
	} // While !feof(inf)

	if (MIME_DNORMAL) if (FFGET_feof(&finf)) fprintf(stdout,"MIME_decode_uu: End of input file hit\n");
	if (MIME_DNORMAL) fprintf(stdout, "MIME_uudec: Completed\n");
	if (inf) fclose(inf);


	return 0;
}





/*-------------------------------------------------
* MIME_decode_text_line
*
 * This function just decodes a single print-quotable line into
* it's normal/original format
*/
int MIME_decode_text_line( char *line )
{

	char c;								/* The Character to output */
	int op, ip; 						/* OutputPointer and InputPointer */
	int slen = strlen(line); /* Length of our line */

	/* Initialise our "pointers" to the start of the encoded string */
	ip=op=0;

	/* for every character in the string... */
	for (ip = 0; ip < slen; ip++)
	{

		c = line[ip];

		/* if we have the quote-printable esc char, then lets get cracking */
		if (c == '=')
		{

			/* if we have another two chars... */
			if (ip <= (slen-2))
			{

				/* convert our encoded character from HEX -> decimal */
				c = (char)hexconv[(int)line[ip+1]]*16 +hexconv[(int)line[ip+2]];

				/* shuffle the pointer up two spaces */
				ip+=2;
			} /* if there were two extra chars after the ='s */

			/* if we didn't have enough characters, then  we'll make the char the
			* string terminator (such as what happens when we get a =\n
			*/
			else
			    {
				line[ip] = '\0';
			} /* else */

		} /* if c was a encoding char */

		/* put in the new character, be it converted or not */
		line[op] = c;

		/* shuffle up the output line pointer */
		op++;
	} /* for */

	/* terminate the line */
	line[op]='\0';

	return (op-1);

}




/*------------------------------------------------------------------------
Procedure:     MIME_decode_TNEF ID:1
Purpose:       Decodes TNEF encoded attachments
Input:
Output:
Errors:
------------------------------------------------------------------------*/
int MIME_decode_TNEF( char *unpackdir, struct _header_info *hinfo, int keep )
{
	int result=0;
	char fullpath[1024];

	/*
	char arg0[]="ripmime";
	char arg1[]="-s";
	char *args[3];

	args[0] = arg0;
	args[1] = arg1;
	args[2] = hinfo->filename;
	*/

	snprintf(fullpath,sizeof(fullpath),"%s/%s",unpackdir,hinfo->filename);

	TNEF_set_path(unpackdir);

	result = TNEF_main( fullpath );

	if (result >= 0)
	{
		//		result = remove( fullpath );
		if (result == -1)
		{
			if (_verbosity) fprintf(stderr,"MIME_decode_TNEF: Removing %s failed (%s)",fullpath,strerror(errno));
		}
	}

	return result;
}




/*------------------------------------------------------------------------
Procedure:     MIME_decode_raw ID:1
Purpose:       Decodes a binary type attachment, ie, no encoding, just raw data.
Input:
Output:
Errors:
------------------------------------------------------------------------*/
int MIME_decode_raw( FFGET_FILE *f, char *unpackdir, struct _header_info *hinfo, int keep )
{
	int result = 0;
	char fullpath[1024];
	int bufsize=1024;
	char *buffer = malloc(bufsize*sizeof(char));
	int readcount;
	int file_has_uuencode = 0;
	FILE *fo;

	/* Decoding / reading a binary attachment is a real interesting situation, as we
	* still use the fgets() call, but we do so repeatedly until it returns a line with a
	* \n\r and the boundary specifier in it.... all in all, I wouldn't rate this code
	* as being perfect, it's activated only if the user intentionally specifies it with
	* --binary flag
	*/

	snprintf(fullpath,sizeof(fullpath),"%s/%s",unpackdir,hinfo->filename);
	fo = fopen(fullpath,"wb");

	if (!fo)
	{
		if (stderrlogging) fprintf(stderr,"MIME_decode_raw: Error, cannot open file %s for writing. (%s)\n\n",fullpath,strerror(errno));
		if (syslogging) syslog(_SL,"MIME_decode_raw: Error, cannot open file %s for writing. (%s)\n\n",fullpath,strerror(errno));
		return -1;
	}

	while ((readcount=FFGET_raw(f, buffer,bufsize)) > 0)
	{
		if ((!file_has_uuencode)&&(MIME_is_uuencode_header( buffer )))
		{
			file_has_uuencode = 1;
		}

		if (MIME_BS_cmp(buffer, readcount))
		{
			break;
		}
		else
		{
			fwrite(buffer,sizeof(char),readcount,fo);
		}
	}

	free(buffer);
	fclose(fo);

	// If there was UUEncoded portions [potentially] in the email, the
	// try to extract them using the MIME_decode_uu()
	//
	if (file_has_uuencode)
	{
		if (MIME_DNORMAL) fprintf(stderr,"Decoding UUencoded data\n");
		result = MIME_decode_uu(unpackdir, hinfo, keep );
		if (strcasecmp(hinfo->uudec_name,"winmail.dat")==0)
		{
			fprintf(stdout,"Decoding TNEF format\n");
			snprintf(hinfo->filename, 128, "%s", hinfo->uudec_name);
			MIME_decode_TNEF( unpackdir, hinfo, keep);
		}
	}

	return result;
}



/*------------------------------------------------------------------------
Procedure:     MIME_decode_text ID:1
Purpose:       Decodes an input stream into a text file.
Input:         unpackdir : directory where to place new text file
hinfo : struct containing information from the last parsed headers
keep : if set, retain the file
Output:
Errors:
------------------------------------------------------------------------*/
int MIME_decode_text( FFGET_FILE *f, char *unpackdir, struct _header_info *hinfo, int keep )
{

	FILE *of; 							// output file

	int linecount = 0;  				// The number of lines

	int file_has_uuencode = 0;			// Flag to indicate this text has UUENCODE in it

	char fullfilename[1024]=""; 	// Filename of the output file

	char line[1024]; 					// The input lines from the file we're decoding

	char *get_result = &line[0];
	int lastlinewasboundary = 0;
	int result = 1;
	int decodesize=0;

	snprintf(fullfilename,sizeof(fullfilename),"%s/%s",unpackdir,hinfo->filename);

	if (MIME_DNORMAL) fprintf(stderr,"Decoding Print Quotable to %s\n",fullfilename);

	if (!f)
	{
		if (syslogging > 0) syslog(_SL,"Error: ripMIME print-quotable input stream broken.");
		if (stderrlogging > 0) fprintf(stderr,"Error: ripMIME print-quotable input stream broken.");
		//exit(_EXITERR_PRINT_QUOTABLE_INPUT_NOT_OPEN);
		return -1;
	}

	// if our FILE stream is open
	if (f)
	{

		of = fopen(fullfilename,"w");
		if (!of)
		{
			if (syslogging > 0) syslog(_SL,"Error: cannot open %s for writing",fullfilename);
			if (stderrlogging > 0) fprintf(stderr,"Error: cannot open %s for writing",fullfilename);
			//			exit(_EXITERR_PRINT_QUOTABLE_OUTPUT_NOT_OPEN);
			return -1;
		}

		while ((get_result = FFGET_fgets(line,1023,f))&&(of))
		{
			if (MIME_DPEDANTIC) fprintf(stdout,"DEBUG:%d: %s",__LINE__,line); // DEBUG

			if ((hinfo->boundary[0] != '\0')&&(MIME_BS_cmp(line,1023)))
			{
				lastlinewasboundary = 1;
				result = 1;
				break;
			}


			if (lastlinewasboundary == 0)
			{
				if (hinfo->content_transfer_encoding == _CTRANS_ENCODING_QP)
				{
					decodesize = MIME_decode_text_line(line);
					if (MIME_DPEDANTIC) fprintf(stdout,"DEBUG:%d:%s",__LINE__,line); // DEBUG
					fwrite(line, 1, decodesize, of);
//					fprintf(of,"%s",line);	//QP decode can result in \0 bytes, so, fprintf is rendered
//					useless, hence we're now using fwrite().
//					CONTRIBUTED by Chea Chee Keong  <cheekeong@transparity.com> (and other TNEF routines)
				}
				else fprintf(of,"%s",line);


				if ((!file_has_uuencode)&&(MIME_is_uuencode_header( line )))
				{
					file_has_uuencode = 1;
				}
			}
			linecount++;

		} // while





		// if the file is still safely open
		if (of)
		{

			// close it
			fclose(of);
			// if we wrote nothing, then trash the file
			if ((keep == 0)||(linecount == 0))
			{
				if (MIME_DNORMAL) fprintf(stderr,"Removing saved attachment (keep=%d, linecount=%d)\n",keep,linecount);
				unlink(fullfilename);
			}
		} // if file still safely open

	} // if main input file stream was open


	// If our input from the file was invalid due to EOF or other
	// then we return a -1 code to indicate that the end has
	// occured.
	//
	if (!get_result) result = -1;

	// If there was UUEncoded portions [potentially] in the email, the
	// try to extract them using the MIME_decode_uu()
	//
	if (file_has_uuencode)
	{
		if (MIME_DNORMAL) fprintf(stderr,"Decoding UUencoded data\n");
		result = MIME_decode_uu( unpackdir, hinfo, keep );
		if (strcasecmp(hinfo->uudec_name,"winmail.dat")==0)
		{
			fprintf(stdout,"Decoding TNEF format\n");
			snprintf(hinfo->filename, 128, "%s", hinfo->uudec_name);
			MIME_decode_TNEF( unpackdir, hinfo, keep );
		}
	}

	return result;
}





/*-------------------------------------------------------------------*
 * MIME_decode64 -
* 	Decodes base64 type streams
*
 * This routine is very very very important, it's the key to ensuring
* we get our attachments out of the email file without trauma!
*
 * NOTE - this has been -slightly altered- in order to make provision
* of the fact that the attachment may end BEFORE the EOF is received
* as is the case with multiple attachments in email.  Hence, we
* now have to detect the start character of the "boundary" marker
*
 * I may consider testing the 1st n' chars of the boundary marker
* just incase it's not always a hypen '-'.
*
 */
int MIME_decode_64( FFGET_FILE *f, char *unpackdir, struct _header_info *hinfo )
{

	int i;
	int cr_count = 0; /* the number of consecutive \n's we've read in, used to detect End of B64 enc */
	int stopcount = 0; /* How many stop (=) characters we've read in */
	int eom_reached = 0; /* flag to say that we've reached the End-Of-MIME encoding. */
	int status = 1; /* Overall status of decoding operation */
	int c; /* a single char as retrieved using MIME_get_char() */
	int char_count = 0; /* How many chars have been received */
	int boundary_crash = 0; /* if we crash into a boundary, set this */
	long int bytecount=0; /* The total file decoded size */
	char output[3]; /* The 4->3 byte output array */
	char input[4]; /* The 4->3 byte input array */
	char fullMIME_filename[_MIME_STRLEN_MAX]=""; /* Full Filename of output file */

	FILE *of; /* output file pointer */

	/* setup our input data stream */
//	FFGET_setstream(f, );

	/* generate the MIME_filename, and open it up... */
	if (_unique_names) MIME_test_uniquename( unpackdir, hinfo->filename, _rename_method );
	snprintf(fullMIME_filename,_MIME_STRLEN_MAX,"%s/%s",unpackdir,hinfo->filename);
	of = fopen(fullMIME_filename,"wb");


	/* if we were unable to open the output file, then we better log an error and drop out */
	if (!of)
	{
		if (syslogging > 0) syslog(_SL,"Error: Cannot open output file %s for BASE64 decoding.",fullMIME_filename);
		if (stderrlogging > 0) fprintf(stderr,"Error: Cannot open output file %s for BASE64 decoding.",fullMIME_filename);
		//		exit(_EXITERR_BASE64_OUTPUT_NOT_OPEN);
		return -1;
	}



	/* collect prefixing trash (if any, such as spaces, CR's etc)*/
	c = MIME_getchar_start(f);

	/* and push the good char back */
	FFGET_ungetc(f,c);


	/* do an endless loop, as we're -breaking- out later */
	while (1)
	{

		/* Initialise the decode buffer */
		input[0] = input[1] = input[2] = input[3] = '0';

		/* snatch 4 characters from the input */
		for (i = 0; i < 4; i++)
		{

			/* get a char from the filestream */
			/* This routine was originally a function we called,
			* but due to the fact that this function can get called
			* millions of times, I figured we'd save some CPU by including
			* it "inline" */
			do {
				c = FFGET_fgetc(f);
			}
			while ( (c != EOF) && ( c < ' ' ) && ( c != '\n' ) && (c != '-') );


			/*	v1.0.0PR5+		c = MIME_getchar(f); -- SEE ABOVE COMMENTS */



			/* if we get a CR then we need to check a few things...*/
			if (c == '\n')
			{
				cr_count++;
				if (cr_count > 1)
				{
					if (MIME_DNORMAL) fprintf(stderr,"EOF Reached due to two consecutive CR's\n");
					eom_reached++;
					break;
				}
				else
				{
					char_count = 0;
					i--;
					continue;
				} // else if it wasn't our 2nd CR
			}
			else
			{
				cr_count=0;
			}



			/* if we get an EOF char, then we know something went wrong */
			if ( c == EOF )
			{
				if (syslogging > 0) syslog(_SL, "Errror: input stream broken for base64 decoding for file %s\n",hinfo->filename);
				status = -1;
				fclose(of);
				return status;
				break;
			} /* if c was the EOF */





			/* if we detect the "stopchar" then we better increment the STOP counter */
			if (c == '=')
			{
				// Once we've found a stop char, we can actually just "pad" in the rest
				// of the stop chars because we know we're at the end. Some MTA's dont
				// put in enough stopchars... at least it seems X-MIMEOLE: Produced By Microsoft MimeOLE V5.50.4133.2400
				// doesnt.

				if (i == 2)
				{
					input[2] = input[3] = (char)b64[c];
				}
				else if (i == 3)
				{
					input[3] = (char)b64[c];
				}

				// Some Microsoft mail generators dont put in sufficient number of = symbols
				// to pad the file out to a multiple of 4 chars. Hence, in order to prevent
				// an over-read, we stop once we detect the first one.

				// NOTE------
				// The "end of the line" has already been absorbed through the FFGET() routines, so, we can
				// just jump out of this FOR loop without worrying that the other characters which exist on
				// the line haveing not been read (because they have been, check the ffget() call, it uses
				// a fgets() routine.

				stopcount = 4 -i;
				if (MIME_DNORMAL) fprintf(stderr,"Stop char detected pos=%d...StopCount = %d\n",i,stopcount);
				i = 4;



				break; // out of FOR.
			}

			/* if we get a '-', there's a damn good chance we've reached into
			* the next boundary line, which is a rare situation, but it CAN
			* happen, especially if you encode small files ( < 50bytes ) and
			* the MTA doesn't place a \n\r between the line and the next
			* boundary */

			if (c == '-' )
			{
				if (FFGET_fgetc(f) == '-')
				{
					boundary_crash++;
					eom_reached++;
					break;
				}
			}

			/* test for and discard invalid chars */
			if (b64[c] == 0x80)
			{
				i--;
				continue;
			}

			/* do the conversion from encoded -> decoded */

			input[i] = (char)b64[c];

			/* assuming we've gotten this far, then we increment the char_count */
			char_count++;

		} // FOR


		// now that our 4-char buffer is full, we can do some fancy bit-shifting and get the required 3-chars of 8-bit data

		output[0] = (input[0] << 2) | (input[1] >> 4);
		output[1] = (input[1] << 4) | (input[2] >> 2);
		output[2] = (input[2] << 6) | input[3];

		// determine how many chars to write write and check for errors if our input char count was 4 then we did receive a propper 4:3 Base64 block, hence write it

		if (i == 4)
		{
			if (fwrite(output, 1, 3-stopcount, of) == EOF)
			{
				/* if there was an error in writing to the file, then we better notify and exit */
				if (syslogging > 0) syslog(_SL,"Error: Cannot write data to %s",fullMIME_filename);
				if (stderrlogging > 0) fprintf(stderr,"Error: Cannot write data to %s",fullMIME_filename);
				//exit(_EXITERR_BASE64_UNABLE_TO_OUTPUT);
				return -1;
			};

			// tally up our total byte conversion count

			bytecount+=(3 -stopcount);

		}
		else if (MIME_DNORMAL) fprintf(stderr,"ERROR - could not attain 4 bytes input\n");


		/* if we wrote less than 3 chars, it means we were at the end of the encoded file thus we exit */
		if ((eom_reached)||(stopcount > 0)||(boundary_crash)||(i!=4))
		{

//			FFGET_closestream(f); // I dont know if I should do this, as there may be other files after in this stream!

			/* close the output file, we're done writing to it */
			fclose(of);

			/* if we didn't really write anything, then trash the  file */
			if (bytecount == 0)
			{
				unlink(fullMIME_filename);
			}

			if (boundary_crash) status = 1; // was _BOUNDARY_CRASH

			//DEBUG
			if (MIME_DNORMAL) fprintf(stderr,"File size = %ld bytes\n",bytecount);
			return status;
		} /* if End-of-MIME or Stopchars appeared */

	} /* while */

	//DEBUG
	//fprintf(stderr,"2.File write size = %d bytes\n",bytecount);

	return status;

}





int MIME_doubleCR_decode( char *filename, char *unpackdir, struct _header_info *hinfo, int current_recursion_level )
{
	int result = 0;
	struct _header_info h;
	char *p;

	if ((p=strrchr(filename,'/'))) p++;
  	else p = filename;

	memcpy(&h, hinfo, sizeof(h));
	snprintf(h.filename, sizeof(h.filename), "%s", p);

	if (MIME_is_file_mime(filename))
	{
		if (_verbosity) fprintf(stdout,"Attempting to decode MIME attachment '%s'\n",filename);
		MIME_unpack( unpackdir, filename, current_recursion_level +1);
	}
	else if (MIME_is_file_uuenc(h.filename))
	{
		if (_verbosity) fprintf(stdout,"Attempting to decode UUENCODED attachment '%s'\n",filename);
		MIME_decode_uu( unpackdir, &h, 1 );
	}

	return result;
}








/*----------------------------------------------------------
* MIME_read
*
 * This routine reads in from stdin and saves everything
* to the file mpname, until EOF is receive
*
 * Equivilant under BASH is just 'cat arbfile > mpname'
*
 */

int MIME_read( char *mpname )
{

	char c;
	long int fsize=-1;

	/* open up our input file */
	FILE *fout = fopen(mpname,"w");


	/* check that out file opened up okay */
	if (!fout)
	{
		if (syslogging > 0) syslog(_SL,"Error: Cannot open file %s for writing... check permissions perhaps?",mpname);
		if (stderrlogging > 0) fprintf(stderr,"Error: Cannot open file %s for writing... check permissions perhaps?",mpname);
		//exit(_EXITERR_MIMEREAD_CANNOT_OPEN_OUTPUT);
		return -1;
	}

	/* assuming our file actually opened up */
	if (fout)
	{

		fsize=0;

		/* while there is more data, consume it */
		while ((c = getc(stdin)) != EOF)
		{

			/* write it to file */
			if (fputc(c,fout) != EOF)
			{
				fsize++;
			}
			else
			    {
				if (syslogging > 0) syslog(_SL,"Error: Cannot write to file %s... maybe you are out of space?", mpname);
				if (stderrlogging > 0) fprintf(stderr,"Error: Cannot write to file %s... maybe you are out of space?",mpname);
				//exit(_EXITERR_MIMEREAD_CANNOT_WRITE_OUTPUT);
				return -1;
			}
		}

		/* clean up our buffers and close */
		fflush(fout);
		fclose(fout);

	} /* end if fout was received okay */

	/* return our byte count in KB */
	return (int)(fsize /1024);
}



/*---------------------------------------------------
* MIME_init_hexconv()
*
 * Initialises the hex->dec conversion
*
 */
int MIME_init_hexconv( void )
{

	hexconv['0'] = 0;
	hexconv['1'] = 1;
	hexconv['2'] = 2;
	hexconv['3'] = 3;
	hexconv['4'] = 4;
	hexconv['5'] = 5;
	hexconv['6'] = 6;
	hexconv['7'] = 7;
	hexconv['8'] = 8;
	hexconv['9'] = 9;
	hexconv['a'] = 10;
	hexconv['b'] = 11;
	hexconv['c'] = 12;
	hexconv['d'] = 13;
	hexconv['e'] = 14;
	hexconv['f'] = 15;
	hexconv['A'] = 10;
	hexconv['B'] = 11;
	hexconv['C'] = 12;
	hexconv['D'] = 13;
	hexconv['E'] = 14;
	hexconv['F'] = 15;

	return 0;
}


/*----------------------------------------------------------
* MIME_init
*
 * Initialises various aspects required for MIME decoding*/
int MIME_init( void )
{

	/* prepare the base64 conversion dictionary */
	MIME_base64_init();
	MIME_init_hexconv();
	_attachment_count = 0;
	_current_line = 0;
	return 0;
}




/*------------------------------------------------------------------------
Procedure:     MIME_decode_encoding ID:1
Purpose:       Based on the contents of hinfo, this function will call the
required function needed to decode the contents of the file
which is contained within the MIME structure
Input:
Output:
Errors:
------------------------------------------------------------------------*/
int MIME_decode_encoding( FFGET_FILE *f, char *unpackdir, struct _header_info *hinfo )
{
	int keep = 1;
	int result = -1;

	if (MIME_DNORMAL) fprintf(stderr,"MIME_decode_encoding: Start: (%s)\n",hinfo->filename);

	// If we have a valid filename, then put it through the process of
	// 	cleaning and filtering
	//
	if (isprint(hinfo->filename[0]))
	{
		if (MIME_DNORMAL) fprintf(stderr,"Filename is valid, cleaning\n");
		MIME_clean_MIME_filename(hinfo->filename);	/* check out thefilename for ISO filenames */
		quick_clean_filename(hinfo->filename); 	/* cleanup garbage characters */
	}

	// If the filename is NOT valid [doesn't have a printable first char]
	// 	then we must create a new file name for it.
	//
	if (!isprint(hinfo->filename[0]))
	{
		sprintf(hinfo->filename,"%s%d",blankfileprefix,filecount);
		if (MIME_DNORMAL) fprintf(stderr,"Filename is not valid, setting to default...(%s)\n",hinfo->filename);
		filecount++;
		if (_no_nameless) keep = 0;
	}
	else
	    if (strncmp(hinfo->filename,blankfileprefix,strlen(blankfileprefix)) != 0)
	{
		_attachment_count++;
	}

	// If we are required to have "unique" filenames for everything, rather than
	// 	allowing ripMIME to overwrite stuff, then we put the filename through
	//		its tests here
	//
	if ((_unique_names)&&(keep)) MIME_test_uniquename( unpackdir, hinfo->filename, _rename_method );

	// If the calling program requested verbosity, then indicate that we're decoding
	//		the file here
	//
	if ((keep)&&(_verbosity)) fprintf(stdout,"Decoding %s\n", hinfo->filename);


	// Select the decoding method based on the content transfer encoding
	// 	method which we read from the headers
	//

	if (MIME_DNORMAL) fprintf(stderr,"ENCODING = %d\n",hinfo->content_transfer_encoding);

	switch (hinfo->content_transfer_encoding)
	{
	case _CTRANS_ENCODING_B64:
		if (MIME_DNORMAL) fprintf(stderr,"Decoding BASE64 format\n");
		result = MIME_decode_64(f, unpackdir, hinfo);
		break;
	case _CTRANS_ENCODING_7BIT:
		if (MIME_DNORMAL) fprintf(stderr,"Decoding 7BIT format\n");
		result = MIME_decode_text(f, unpackdir, hinfo, keep);
		break;
	case _CTRANS_ENCODING_8BIT:
		if (MIME_DNORMAL) fprintf(stderr,"Decoding 8BIT format\n");
		result = MIME_decode_text(f, unpackdir, hinfo, keep);
		break;
	case _CTRANS_ENCODING_RAW:
		if (MIME_DNORMAL) fprintf(stderr,"Decoding RAW format\n");
		result = MIME_decode_raw(f, unpackdir, hinfo, keep);
		result = 1;
		break;
	case _CTRANS_ENCODING_QP:
		if (MIME_DNORMAL) fprintf(stderr,"Decoding QuotePrintable format\n");
		result = MIME_decode_text(f, unpackdir, hinfo, keep);
		break;
	case _CTRANS_ENCODING_UNKNOWN:
		result = MIME_decode_text(f, unpackdir, hinfo, keep);
		if (MIME_DNORMAL) fprintf(stderr,"UNKNOWN Decode completed\n");
		break;
	case _CTRANS_ENCODING_UNSPECIFIED:
		if (MIME_DNORMAL) fprintf(stderr,"Decoding UNSPECIFIED format\n");
		result = MIME_decode_text(f, unpackdir, hinfo, keep);
		break;
	default:
		if (MIME_DNORMAL) fprintf(stderr,"Decoding format is not defined (%d)\n",hinfo->content_transfer_encoding);
		if (syslogging > 0) syslog(1,"MIME_unpack_stage2(): Unknown encoding %d",hinfo->content_transfer_encoding);
		result = MIME_decode_raw(f, unpackdir, hinfo, keep);
		result = 1;
		break;
	}

	if ((result != -1)&&(hinfo->content_type == _CTYPE_TNEF))
	{
		if ((MIME_DNORMAL)||(_verbosity)) fprintf(stdout,"Decoding TNEF format\n");
		_attachment_count++;
		MIME_decode_TNEF( unpackdir, hinfo, 0 );
	}

	// Look for Microsoft MHT files... and try decode them.
	//	MHT files are just embedded email files, except they're usually
	//	encoded as BASE64... so, you have to -unencode- them, to which
	//	you find out that lo, you have another email.

	if ( (result != -1) && ( (strstr(hinfo->filename,".mht"))||(strstr(hinfo->name,".mht"))) )
	{
		fprintf(stdout,"Last filename was : %s\n",hinfo->name);
		snprintf(hinfo->scratch,sizeof(hinfo->scratch),"%s/%s",unpackdir,hinfo->name);
		MIME_unpack( unpackdir, hinfo->scratch, (hinfo->current_recursion_level+1) );
	}

	return result;
}




/*------------------------------------------------------------------------
Procedure:     MIME_unpack_stage2 ID:1
Purpose:       This function commenced with the file decoding of the attachments
as required by the MIME structure of the file.
Input:
Output:
Errors:
------------------------------------------------------------------------*/
int MIME_unpack_stage2( FFGET_FILE *f, char *unpackdir, struct _header_info *hinfo, int current_recursion_level )
{
	int result = 1;
	struct _header_info *h;
	char *p;

	if (MIME_DNORMAL) fprintf(stderr,"MIME_unpack_stage2: Start, recursion %d\n",current_recursion_level);

	if (current_recursion_level > _RECURSION_LEVEL_MAX)
	{
		if (syslogging > 0) syslog(_SL,"MIME_unpack_stage2(): Current Recursion level of %d is greater than permitted %d",current_recursion_level, _RECURSION_LEVEL_MAX);
		if (stderrlogging > 0) fprintf(stderr,"MIME_unpack_stage2(): Current Recursion level of %d is greater than permitted %d\n",current_recursion_level, _RECURSION_LEVEL_MAX);
		return -1;
	}

	h = hinfo;

	// Get our headers and determin what we have...
	//
	if (MIME_DNORMAL) fprintf(stderr,"Parsing headers (initial)\n");

	// Parse the headers, extracting what information we need
	//
	result = MIMEH_parse_headers(f,h);

	if (MIMEH_doubleCR)
	{
		MIME_doubleCR_decode(MIMEH_doubleCRname, unpackdir, h, current_recursion_level);
		MIMEH_doubleCR = 0;
		FFGET_SDL_MODE = 0;
	}

	// If we dont get what we expected, then jump out before
	// 	we push things too far and possibly cause a segfault
	//
	if (result == -1) return result;

	// If we located a boundary being specified (as apposed to existing)
	// then we push it to the BoundaryStack
	//
	if (h->boundary_located)
	{
		if (MIME_DNORMAL) fprintf(stderr,"Boundary located, pushing to stack (%s)\n",h->boundary);
		MIME_BS_push(h->boundary);
		h->boundary_located = 0;
	}
	else
	    {
		if (MIME_DNORMAL) fprintf(stderr,"Decoding in BOUNDARY-LESS mode\n");

		if ((h->content_type == _CTYPE_RFC822)||(h->content_type == _CTYPE_MULTIPART))
		{
			if (MIME_DNORMAL) fprintf(stderr,"Decoding multipart/embedded message\n");

			// If there is no filename, then we have a "standard"
			// embedded message, which can be just read off as a
			// continuous stream (simply with new boundaries
			//

			if (( h->content_transfer_encoding != _CTRANS_ENCODING_B64)&&( h->filename[0] == '\0' ))
			{
				if (MIME_DNORMAL) fprintf(stderr,"Non base64 encoding AND no filename, embedded message\n");

				h->boundary_located = 0;

				result = MIME_unpack_stage2(f, unpackdir, h, current_recursion_level +1);

				p = MIME_BS_top();
				if (p) zstrncpy(h->boundary, p,sizeof(h->boundary));
			}
			else
			    {
				if (MIME_DNORMAL) fprintf(stderr,"embedded message has a filename, decoding to file %s",h->filename);
				result = MIME_decode_encoding( f, unpackdir, h );
				result = MIME_unpack_single( unpackdir, h->filename, current_recursion_level +1);
			}
		}
		else
		    {
			if (MIME_DNORMAL) fprintf(stderr,"Decoding boundaryless file (%s)...\n",h->filename);
			result = MIME_decode_encoding( f, unpackdir, h );
		}

		return result;
	}

	if ((MIME_BS_top()!=NULL)&&(result == 1))
	{

		if (MIME_DNORMAL) fprintf(stderr,"Decoding with boundaries (filename = %s)\n",h->filename);

		// Explain this..... if the first headers of the message says RFC822, then we
		// have in effect a wrapped up message, a little crazy to have, but, happens
		// 	So, we dont want to try and read the headers in that case
		//
		result = MIME_decode_encoding(f, unpackdir, h);

		//		if (result == 0) result = 1;

		if (result == 1)
		{

			if (MIME_BS_top()!=NULL)
			{

				// As this is a multipart email, then, each section will have its
				// own headers, so, we just simply call the MIMEH_parse call again
				// and get the attachment details
				//
				while (result == 1)
				{
					h->content_type = -1;
					h->filename[0] = '\0';
					h->name[0]     = '\0';
					h->content_transfer_encoding = -1;
					h->content_disposition = -1;

					if (MIME_DNORMAL) fprintf(stderr,"Decoding headers...\n");
					result = MIMEH_parse_headers(f,h);
					if (h->boundary_located)
					{
						if (MIME_DNORMAL) fprintf(stderr,"Pushing boundary %s\n",h->boundary);
						MIME_BS_push(h->boundary);
						h->boundary_located = 0;
					}

					if (result == _MIMEH_FOUND_FROM)
					{
						return _MIMEH_FOUND_FROM;
					}

					if (result == 1)
					{

						// If we locate a new boundary specified, it means we have a
						// embedded message, also if we have a ctype of RFC822
						//
						if ( (h->boundary_located) \
						|| (h->content_type == _CTYPE_RFC822)\
					  	|| (h->content_type == _CTYPE_MULTIPART)\
					   )
						{
							if (MIME_DNORMAL) fprintf(stderr,"Multipart mail headers found\n");

							/* If there is no filename, then we have a "standard"
							* embedded message, which can be just read off as a
							* continuous stream (simply with new boundaries */
							if (( h->content_transfer_encoding != _CTRANS_ENCODING_B64)&&(h->filename[0] == '\0' ))
							{
								if (MIME_DNORMAL) fprintf(stderr,"NON-BASE64 DECODE\n");
								h->boundary_located = 0;
								result = MIME_unpack_stage2(f, unpackdir, h, current_recursion_level +1);

								p = MIME_BS_top();
								if (p) snprintf(h->boundary,_MIME_STRLEN_MAX,"%s",p);
							}
							else
							    {
								result = MIME_decode_encoding( f, unpackdir, h );
								result = MIME_unpack_single( unpackdir, h->filename, current_recursion_level +1);
							}
						}
						else
						    {
							result = MIME_decode_encoding( f, unpackdir, h );
						}
					}
					else break;

				} // While (result)

				if (result == 1) MIME_BS_pop();

			} // if MIME_BS_top()

		} // if result == 1

	} // if (result)


	return result;
}






/*------------------------------------------------------------------------
Procedure:     MIME_decode_mailbox ID:1
Purpose:       Decodes mailbox formatted email files
Input:
Output:
Errors:
------------------------------------------------------------------------*/
int MIME_unpack_mailbox( char *unpackdir, char *mpname, int current_recursion_level )
{
	FFGET_FILE f;
	FILE *fi;
	FILE *fo;
	char fname[1024];
	char line[1024];
	int mcount=0;
	int lastlinewasblank=1;
	int result;

	snprintf(fname,sizeof(fname),"%s/tmp.email000.mailpack",unpackdir);

	fi = fopen(mpname,"r");
	if (!fi)
	{
		if (syslogging > 0) syslog(_SL,"MIME_unpack_mailbox: Cannot open '%s' for reading (%s)",mpname,strerror(errno));
		if (stderrlogging > 0) fprintf(stderr,"MIME_unpack_mailbox: Cannot open '%s' for reading (%s)\n",mpname,strerror(errno));
		return -1;
	}

	fo = fopen(fname,"w");
	if (!fo)
	{
		if (syslogging > 0) syslog(_SL,"MIME_unpack_mailbox: Cannot open '%s' for writing  (%s)",fname,strerror(errno));
		if (stderrlogging > 0) fprintf(stderr,"MIME_unpack_mailbox: Cannot open '%s' for writing (%s)\n",fname,strerror(errno));
		return -1;
	}

	FFGET_setstream(&f, fi);

	while (FFGET_fgets(line,1024,&f))
	{
		// If we have the construct of "\n\rFrom ", then we
		//		can be -pretty- sure that a new email is about
		//		to start
		//
		if ((lastlinewasblank==1)&&(strncasecmp(line,"From ",5)==0))
		{
			// Close the mailpack
			//
			fclose(fo);

			// Now, decode the mailpack
			//
			MIME_unpack_single(unpackdir, fname, current_recursion_level);

			// Remove the now unpacked mailpack
			//
			result = remove(fname);
			if (result == -1)
			{
				if (syslogging > 0) syslog(_SL,"MIME_unpack_mailbox: Error removing temporary mailpack '%s' (%s)",fname,strerror(errno));
			}

			// Create a new mailpack filename, and keep on going...
			//
			snprintf(fname,sizeof(fname),"%s/tmp.email%03d.mailpack",unpackdir,++mcount);
			fo = fopen(fname,"w");
		}
		else
		{
			fprintf(fo,"%s",line);
		}

		// If the line is blank, then note this down because
		// 	if our NEXT line is a From, then we know that
		//		we have reached the end of the email
		//
		if ((line[0] == '\n') || (line[0] == '\r'))
		{
			lastlinewasblank=1;
		}
		else lastlinewasblank=0;

	} // While fgets()

	fclose(fi);

	// Now, even though we have run out of lines from our main input file
	// 	it DOESNT mean we dont have some more decoding to do, in fact
	//		quite the opposite, we still have one more file to decode
	//

	// Close the mailpack
		//
		fclose(fo);

	// Now, decode the mailpack
		//
		MIME_unpack_single(unpackdir, fname, current_recursion_level);

	// Remove the now unpacked mailpack
		//
		result = remove(fname);
	if (result == -1)
	{
		if (syslogging > 0) syslog(_SL,"MIME_unpack_mailbox: Error removing temporary mailpack '%s' (%s)",fname,strerror(errno));
	}

	return 0;
}



/*---------------------------------------------------
* MIME_unpack_single
*
 * Breaks the MIME package into its various files
*/
int MIME_unpack_single( char *unpackdir, char *mpname, int current_recursion_level )
{
	struct _header_info h;
	int result = 0;
	int status = 0;		/* Global status */
	FFGET_FILE f;
	FILE *fi;			/* Pointer for the MIME file we're going to be going through */
	FILE *hf = NULL;


	// Because this MIME module gets used in both CLI and daemon modes
	// 	we should check to see that we can report to stderr
	//

	_MIME_debug = _MIME_debug & stderrlogging;

	if (MIME_DNORMAL) fprintf(stderr,"MIME_unpack_single: dir=%s packname=%s level=%d\n",unpackdir, mpname, current_recursion_level);

	if (current_recursion_level > _RECURSION_LEVEL_MAX)
	{
		if (syslogging > 0) syslog(_SL,"MIME_unpack_single: Current Recursion level of %d is greater than permitted %d",current_recursion_level, _RECURSION_LEVEL_MAX);
		if (stderrlogging > 0) fprintf(stderr,"MIME_unpack_single: Current Recursion level of %d is greater than permitted %d\n",current_recursion_level, _RECURSION_LEVEL_MAX);
		return -1;
	} else h.current_recursion_level = current_recursion_level;

	_current_line = 0;

	/* if we're reading in from STDIN */
	if( mpname[0] == '-' && mpname[1] == '\0' )
	{
		fi = stdin;
	}
	else
	    {
		fi = fopen(mpname,"r");
		if (!fi)
		{
			if (syslogging > 0) syslog(_SL,"MIME_unpack_single: Error opening '%s' for reading (%s)",mpname,strerror(errno));
			return -1;
		}
	}

	if ((!hf)&&(_dump_headers))
	{
		hf = fopen(headersname,"w");
		if (!hf)
		{
			_dump_headers = 0;
			if (syslogging > 0) syslog(_SL,"MIME_unpack_single: Cannot open '%s' for writing  (%s)",headersname,strerror(errno));
			if (stderrlogging > 0) fprintf(stderr,"MIME_unpack_single: Cannot open '%s' for writing (%s)\n",headersname,strerror(errno));
		}
		else
		    {
			MIMEH_set_headers_save(hf);
		}
	}

	/* check to see if we had problems opening the file */
	if (!fi)
	{
		if (syslogging > 0) syslog(_SL,"MIME_unpack_single: Could not open mailpack file '%s' (%s)",mpname, strerror(errno));
		if (stderrlogging > 0) fprintf(stderr,"MIME_unpack_single: Could not open mailpack file '%s' (%s)\n\n",mpname, strerror(errno));
		return -1;
	}

	FFGET_setstream(&f, fi);

	h.content_type = -1;
	h.boundary[0] = '\0';
	h.boundary_located = 0;
	h.filename[0] = '\0';
	h.name[0]     = '\0';
	h.content_transfer_encoding = -1;
	h.content_disposition = -1;
	result = MIME_unpack_stage2(&f, unpackdir, &h, 0);

	fclose(fi);

	if (_dump_headers)
	{
		if (hf) fclose(hf);
	}

	return status;
}






/*------------------------------------------------------------------------
Procedure:     MIME_unpack ID:1
Purpose:       Front end to unpack_mailbox and unpack_single.  Decides
which one to execute based on the mailbox setting
Input:
Output:
Errors:
------------------------------------------------------------------------*/
int MIME_unpack( char *unpackdir, char *mpname, int current_recursion_level )
{
	int result = 0;

	if (_mailbox_format > 0)
		result = MIME_unpack_mailbox( unpackdir, mpname, current_recursion_level );
	else
	    result = MIME_unpack_single( unpackdir, mpname, current_recursion_level );

	return result;

}






/*--------------------------------------------------------------------
* MIME_close
*
* Closes the files used in MIME_unpack, such as headers etc */
int MIME_close( void )
{
	if (headers)
	{
		fclose(headers);
	}

	return 0;
}




/*----------END OF MIME.c------------*/

