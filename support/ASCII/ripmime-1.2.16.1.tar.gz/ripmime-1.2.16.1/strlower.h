#ifndef __STRLOWER__
#define __STRLOWER__

int strlower( char *convertme );

#endif

