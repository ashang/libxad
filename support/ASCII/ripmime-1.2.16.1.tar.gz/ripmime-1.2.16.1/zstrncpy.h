extern char *zstrncpy (char *dst, const char *src, size_t len);
